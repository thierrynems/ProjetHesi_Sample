package univdschang.org.web;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import univdschang.org.dao.EtudiantRepository;
import univdschang.org.entities.Etudiant;

@Controller
public class EtudiantController {
	@Autowired
	private EtudiantRepository etudiantRepository;
	@RequestMapping(value="/index")
	public String index(Model model,
			@RequestParam(name="page",defaultValue="0")int page,
			@RequestParam(name="size",defaultValue="5")int size,
			@RequestParam(name="key",defaultValue="")String key){
	Page<Etudiant> etudiants=etudiantRepository.search("%"+key+"%",new PageRequest(page, size));
	
	model.addAttribute("listeEtudiants", etudiants.getContent());
	int[] pages=new int[etudiants.getTotalPages()];
	model.addAttribute("pages",pages);
	model.addAttribute("key",key);
		return "etudiant";
	}
	//Ajouter un etudiant 
	@RequestMapping(value="/etudiant")
	public String etudiant(){
	 
		return "addetudiant";
	}
	//enregistrer un etudiant
	@RequestMapping(value="/saveetudiant")
	public String add(
			@RequestParam(name="nom",defaultValue="0")String nom,
			@RequestParam(name="prenom",defaultValue="5")String prenom,
			@RequestParam(name="lieunaissance",defaultValue="")String lieunaiss,
			@RequestParam(name="cni",defaultValue="")String cni,
			@RequestParam(name="tel",defaultValue="")long tel,
			@RequestParam(name="email",defaultValue="")String email,
			@RequestParam(name="sexe",defaultValue="")String sexe){
			
			Etudiant etud=new Etudiant();
			//DateFormat df =new SimpleDateFormat("dd/MM/yyyy");
			etud.setCni(cni);
			//etud.setDatenaissance(df.parse(datenaiss));
		    //etud.setDatenaissance(datenaiss);
			etud.setEmail(email);
			etud.setLieunaissance(lieunaiss);
			etud.setNom(nom);
			etud.setPrenom(prenom);
			etud.setSexe(sexe);
			etud.setTel(tel);
			etudiantRepository.save(etud);
		    return "redirect:/etudiant";
	}
}
